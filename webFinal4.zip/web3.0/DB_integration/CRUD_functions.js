const sql = require("./db.js");// ייבוא החיבור למסד הנתונים

const CRUD = {};// אובייקט ריק שיכיל את פונקציות ה-CRUD שלנו

// ---------------------------------------------------------
// 1. משתמשים (Users)
// ---------------------------------------------------------
// יצירת משתמש חדש
CRUD.createUser = (newUser, result) => {
    // 1. קודם כל בודקים אם שם המשתמש או המייל כבר קיימים
    sql.query("SELECT * FROM users WHERE username = ? OR email = ?", [newUser.username, newUser.email], (err, resCheck) => {
        if (err) {
            console.log("error checking existence: ", err);
            result(err, null);
            return;
        }

        // אם חזר תוצאה, סימן שמשהו תפוס
        if (resCheck.length > 0) {
            const existingUser = resCheck[0];
            // בודקים מה בדיוק תפוס כדי לתת הודעה מדויקת
            if (existingUser.username === newUser.username) {
                result({ kind: "username_exists" }, null);
                return;
            }
            if (existingUser.email === newUser.email) {
                result({ kind: "email_exists" }, null);
                return;
            }
        }

        // 2. אם לא קיים, ממשיכים ביצירת המשתמש
        const query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        sql.query(query, [newUser.username, newUser.email, newUser.password], (err, res) => {
            if (err) {
                console.log("error creating user: ", err);
                result(err, null);
                return;
            }
            // הצלחה!
            result(null, { id: res.insertId, ...newUser });
        });
    });
};
// התחברות משתמש
CRUD.loginUser = (email, password, result) => {
    const query = "SELECT * FROM users WHERE email = ? AND password = ?";
    sql.query(query, [email, password], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        if (res.length) {
            result(null, res[0]);
            return;
        }
        result({ kind: "not_found" }, null);
    });
};

// ---------------------------------------------------------
// 2. ניהול לייבלים (Labels) 
// ---------------------------------------------------------

// יצירת לייבל חדש
CRUD.createUserLabel = (username, labelName, result) => {
    const query = "INSERT INTO user_labels (username, label_name) VALUES (?, ?)";
    sql.query(query, [username, labelName], (err, res) => {
        if (err) {
            console.log("error adding label: ", err);
            result(err, null);
            return;
        }
        result(null, { id: res.insertId, label_name: labelName });
    });
};

// שליפת כל הלייבלים של משתמש
CRUD.getUserLabels = (username, result) => {
    const query = "SELECT * FROM user_labels WHERE username = ?";
    sql.query(query, [username], (err, res) => {
        if (err) {
            console.log("error fetching labels: ", err);
            result(err, null);
            return;
        }
        result(null, res);
    });
};

// עדכון לייבל למתכון ספציפי
CRUD.updateRecipeLabel = (username, recipeId, labelId, result) => {
    // אם labelId הוא null (המשתמש בחר "ללא תווית")
    const query = "UPDATE user_recipes SET label_id = ? WHERE username = ? AND recipe_id = ?";
    sql.query(query, [labelId, username, recipeId], (err, res) => {
        if (err) {
            console.log("error updating recipe label: ", err);
            result(err, null);
            return;
        }
        result(null, { success: true });
    });
};

// ---------------------------------------------------------
// 3. מתכונים (Recipes)
// ---------------------------------------------------------

// שליפת מתכון לפי מזהה (עודכן כדי לקבל גם את הלייבל הנוכחי אם יש שם משתמש)
CRUD.getRecipeById = (recipeId, username, result) => {
    // שאילתה מורכבת: גם נתוני מתכון, גם רכיבים, וגם (אם המשתמש קיים) הלייבל שלו
    let query = `
        SELECT r.*, i.name as ing_name, i.unit, i.quantity, ur.label_id 
        FROM recipes r 
        LEFT JOIN ingredients i ON r.id = i.recipe_id 
        LEFT JOIN user_recipes ur ON r.id = ur.recipe_id AND ur.username = ?
        WHERE r.id = ?`;

    // הפרמטר הראשון הוא username (עבור ה-JOIN), השני הוא recipeId
    sql.query(query, [username, recipeId], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length) {
            const recipeData = {
                id: res[0].id,
                title: res[0].title,
                servings: res[0].servings,
                instructions: res[0].instructions,
                image: res[0].image_path,
                label_id: res[0].label_id, 
                ingredients: []
            };

            res.forEach(row => {
                if (row.ing_name) {
                    recipeData.ingredients.push({
                        name: row.ing_name,
                        unit: row.unit,
                        quantity: row.quantity
                    });
                }
            });

            result(null, recipeData);
            return;
        }

        result({ kind: "not_found" }, null);
    });
};

// יצירת מתכון חדש
CRUD.createNewRecipe = (recipeData, result) => {
    const newRecipe = {
        title: recipeData.title,
        servings: recipeData.servings,
        instructions: recipeData.instructions,
        image_path: recipeData.image_path || 'images/default-recipe.jpg'
    };

    sql.query("INSERT INTO recipes SET ?", newRecipe, (err, res) => {
        if (err) {
            console.log("error inserting recipe: ", err);
            result(err, null);
            return;
        }

        const newRecipeId = res.insertId;
        const userRecipeLink = { username: recipeData.username, recipe_id: newRecipeId };

        sql.query("INSERT INTO user_recipes SET ?", userRecipeLink, (err, resLink) => {
            if (err) {
                console.log("error linking user: ", err);
                result(err, null);
                return;
            }

            if (!recipeData.ingredients || recipeData.ingredients.length === 0) {
                result(null, { id: newRecipeId, ...newRecipe });
                return;
            }

            const ingredientsValues = recipeData.ingredients.map(ing => [
                newRecipeId, ing.name, ing.unit, ing.quantity
            ]);

            sql.query("INSERT INTO ingredients (recipe_id, name, unit, quantity) VALUES ?", [ingredientsValues], (err, resIng) => {
                if (err) {
                    console.log("error ingredients: ", err);
                    result(err, null);
                    return;
                }
                result(null, { id: newRecipeId, ...newRecipe });
            });
        });
    });
};

// שליפת מתכונים לפי שם משתמש (עבור הפרופיל)
CRUD.getRecipesByUser = (username, result) => {
    const query = `
        SELECT r.*, ul.label_name
        FROM recipes r
        JOIN user_recipes ur ON r.id = ur.recipe_id
        LEFT JOIN user_labels ul ON ur.label_id = ul.id
        WHERE ur.username = ?`;

    sql.query(query, [username], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        result(null, res);
    });
};

// הסרת מתכון מפרופיל משתמש
CRUD.removeRecipeFromUser = (username, recipeId, result) => {
    const query = "DELETE FROM user_recipes WHERE username = ? AND recipe_id = ?";

    sql.query(query, [username, recipeId], (err, res) => {
        if (err) {
            console.log("error deleting user_recipe link: ", err);
            result(err, null);
            return;
        }

        // בדיקה אם בכלל נמחק משהו (אם לא, כנראה לא היה קשר כזה)
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }

        result(null, { message: "Recipe removed from user profile" });
    });
};


// שיתוף מתכון עם משתמש אחר
CRUD.shareRecipe = (recipeId, targetUsername, result) => {
    // 1. קודם כל נבדוק אם המשתמש שאליו שולחים קיים בכלל
    sql.query("SELECT * FROM users WHERE username = ?", [targetUsername], (err, resUsers) => {
        if (err) {
            console.log("error checking user: ", err);
            result(err, null);
            return;
        }

        if (resUsers.length === 0) {
            result({ kind: "user_not_found" }, null);
            return;
        }

        // 2. אם המשתמש קיים, נבדוק אם המתכון כבר קיים אצלו כדי לא ליצור כפילות
        sql.query("SELECT * FROM user_recipes WHERE username = ? AND recipe_id = ?", [targetUsername, recipeId], (err, resExist) => {
            if (err) {
                console.log("error checking existing share: ", err);
                result(err, null);
                return;
            }

            if (resExist.length > 0) {
                // המתכון כבר משותף איתו - נחזיר הצלחה 
                result(null, { message: "Recipe already shared with this user." });
                return;
            }

            // 3. הוספת המתכון למשתמש היעד (ללא לייבל בהתחלה)
            const shareData = {
                username: targetUsername,
                recipe_id: recipeId,
                label_id: null
            };

            sql.query("INSERT INTO user_recipes SET ?", shareData, (err, resInsert) => {
                if (err) {
                    console.log("error sharing recipe: ", err);
                    result(err, null);
                    return;
                }
                result(null, { message: "Success" });
            });
        });
    });
};

module.exports = CRUD;