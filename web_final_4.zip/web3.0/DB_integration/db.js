const mysql = require("mysql2"); 
const dbConfig = require("./db.config.js"); 

const db = dbConfig.DB;
//צור את החיבור למסד הנתונים
const connection = mysql.createConnection({
    host: dbConfig.HOST,
    user: dbConfig.USER,
    password: dbConfig.PASSWORD,
    database: dbConfig.DB
});

//פתח את החיבור למסד הנתונים
connection.connect(error => {
    if (error) throw error;
    console.log(`Successfully connected to the database: ${db}.`);
});

//ייצא את החיבור לשימוש בקבצים אחרים
module.exports = connection;
