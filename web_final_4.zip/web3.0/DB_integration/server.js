const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const multer = require('multer'); // multer כדי לטפל בקבצים
const CRUD_functions = require("./CRUD_functions.js");
const fs = require('fs');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// הגדרת התיקייה הראשית
const parentDir = path.join(__dirname, '../');
app.use(express.static(parentDir));

// --- Multer ---
// מגדיר איפה לשמור את התמונות ואיך לקרוא להן
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const dir = path.join(parentDir, 'images');
        // אם התיקייה לא קיימת אזז יוצר אותה כדי למנוע שגיאות
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir);
        }
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        // מייצר שם ייחודי עם תאריך ומספר רנדומלי למניעת דריסת קבצים
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, file.fieldname + '-' + uniqueSuffix + ext);
    }
});

const upload = multer({ storage: storage });

// --- נתיבי אימות (Auth) ---
app.get('/', (req, res) => {
    res.sendFile(path.join(parentDir, 'login.html'));
});

// הרשמה
app.post('/signup', (req, res) => {
    const newUser = {
        username: req.body.username,
        email: req.body.email,
        password: req.body.password
    };
    // משתמש בפונקציית ה-CRUD ליצירת משתמש חדש
    CRUD_functions.createUser(newUser, (err, data) => {
        if (err) {
            if (err.kind === "username_exists") // שם המשתמש תפוס
            {
                return res.status(409).send({ success: false, message: "Username already taken." });
            }
            if (err.kind === "email_exists") // המייל תפוס
            {
                return res.status(409).send({ success: false, message: "Email already registered." });
            }
            // שגיאה כללית אחרת
            return res.status(500).send({ success: false, message: "Error registering user." });
        }
        res.send({ success: true, message: "Registered successfully!" });
    });
});
// התחברות
app.post('/login', (req, res) => {
    CRUD_functions.loginUser(req.body.email, req.body.password, (err, user) => {
        if (err) {
            if (err.kind === "not_found") return res.status(401).send({ success: false, message: "Invalid credentials." });
            return res.status(500).send({ success: false, message: "Server error." });
        }
        res.send({ success: true, message: `Welcome back, ${user.username}!` });
    });
});

// --- מתכונים (Recipes) ---

// יצירת מתכון חדש
app.post('/new-recipe', upload.single('image'), (req, res) => {
    // הרכיבים מגיעים כמחרוזת בגלל ה-FormData, אז ממיר חזרה ל-JSON
    let ingredients = [];
    try {
        ingredients = JSON.parse(req.body.ingredients);
    } catch (e) {
        ingredients = [];
    }

    // אם הועלתה תמונה שומר את הנתיב שלה, אחרת שם תמונת ברירת מחדל
    const imagePath = req.file ? `images/${req.file.filename}` : 'images/default-recipe.jpg';

    const recipeData = {
        username: req.body.username,
        title: req.body.title,
        servings: req.body.servings,
        instructions: req.body.instructions,
        image_path: imagePath,
        ingredients: ingredients
    };

    if (!recipeData.title || !recipeData.username) {
        return res.status(400).send({ message: "Missing title or username." });
    }

    CRUD_functions.createNewRecipe(recipeData, (err, data) => {
        if (err) return res.status(500).send({ message: "Error creating recipe." });
        res.send({ success: true, message: "Recipe created!", id: data.id });
    });
});

app.get('/recipes', (req, res) => {
    const username = req.query.username;
    if (username) {
        CRUD_functions.getRecipesByUser(username, (err, data) => {
            if (err) return res.status(500).send({ message: "Error retrieving recipes." });
            res.send(data);
        });
    } else {
        res.send([]);
    }
});

// מחיקת מתכון מהפרופיל (ניתוק הקשר)
app.delete('/api/user_recipes', (req, res) => {
    const { username, recipeId } = req.body; // מקבלים את הנתונים מהבקשה

    CRUD_functions.removeRecipeFromUser(username, recipeId, (err, data) => {
        if (err) {
            return res.status(500).send({ message: "Error removing recipe" });
        }
        res.send({ success: true });
    });
});

// --- לייבלים ---
// יצירת לייבל חדש
app.post('/api/labels', (req, res) => {
    const { username, label_name } = req.body;
    if (!username || !label_name) return res.status(400).send({ message: "Missing info" });

    CRUD_functions.createUserLabel(username, label_name, (err, data) => {
        if (err) return res.status(500).send({ message: "Error creating label" });
        res.send({ success: true, label: data });
    });
});
// שליפת לייבלים של משתמש
app.get('/api/labels/:username', (req, res) => {
    CRUD_functions.getUserLabels(req.params.username, (err, data) => {
        if (err) return res.status(500).send({ message: "Error fetching labels" });
        res.send(data);
    });
});
// עדכון לייבל למתכון
app.post('/api/recipe/update-label', (req, res) => {
    const { username, recipe_id, label_id } = req.body;
    CRUD_functions.updateRecipeLabel(username, recipe_id, label_id, (err, data) => {
        if (err) return res.status(500).send({ message: "Error updating label" });
        res.send({ success: true });
    });
});
// שליפת מתכון לפי מזהה (כולל לייבל אם קיים)
app.get('/api/recipe/:id', (req, res) => {
    const username = req.query.username || null;
    CRUD_functions.getRecipeById(req.params.id, username, (err, data) => {
        if (err) {
            if (err.kind === "not_found") return res.status(404).send({ message: "Not found" });
            return res.status(500).send({ message: "Server error" });
        }
        res.send(data);
    });
});

// שיתוף מתכון
app.post('/api/share', (req, res) => {
    const { recipeId, targetUsername } = req.body;

    if (!recipeId || !targetUsername) {
        return res.status(400).send({ message: "Missing info." });
    }
    // קריאה לפונקציית השיתוף
    CRUD_functions.shareRecipe(recipeId, targetUsername, (err, data) => {
        if (err) {
            if (err.kind === "user_not_found") {
                return res.status(404).send({ success: false, message: "User not found!" });
            }
            return res.status(500).send({ success: false, message: "Error sharing recipe." });
        }
        res.send({ success: true, message: "Recipe shared successfully!" });
    });
});


// הפעלת השרת
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});