module.exports = {
     HOST: "localhost",
     USER: "root",
     PASSWORD: "projWeb", 
     DB: "mysql"
};
