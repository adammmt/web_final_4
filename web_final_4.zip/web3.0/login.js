document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');// טופס ההתחברות/הרשמה
    const toggleSignupBtn = document.getElementById('toggle-signup');// כפתור לעבור בין התחברות להרשמה
    const usernameInput = document.getElementById('username');// שדה שם משתמש (להרשמה)
    const submitBtn = document.getElementById('submit-btn');// כפתור שליחה
    const errorMessage = document.getElementById('error-message');// אלמנט להצגת הודעות שגיאה

    errorMessage.className = 'errorMessage';
    // הוספת מחלקת CSS להודעת השגיאה
    let isSigningUp = false;
    // מצב התחברות כבר קיים כברירת מחדל
    toggleSignupBtn.addEventListener('click', () => {
        isSigningUp = !isSigningUp;
        if (isSigningUp) {
            usernameInput.style.display = 'block';
            loginForm.insertBefore(usernameInput, document.getElementById('email'));
            submitBtn.textContent = 'Join!';
            toggleSignupBtn.textContent = 'I have an account, let me log in';
            usernameInput.setAttribute('required', 'true');
        } else {
            usernameInput.style.display = 'none';
            submitBtn.textContent = 'Log In';
            toggleSignupBtn.textContent = "I'm new! Let's create an account";
            usernameInput.removeAttribute('required');
        }
        errorMessage.textContent = '';
    });
    // טיפול בשליחת הטופס
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        errorMessage.textContent = '';
        errorMessage.classList.remove('error-shake');

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const username = usernameInput.value.trim();

        let isValid = true;

        // ולידציה בסיסית
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showError('Invalid email format.');
            isValid = false;
        } else if (password.length < 1) {
            showError('Password cannot be empty.');
            isValid = false;
        } else if (isSigningUp && username === '') {
            showError('Please enter a username.');
            isValid = false;
        }

        if (!isValid) return;

        const endpoint = isSigningUp ? '/signup' : '/login';
        const dataPayload = { email, password };
        if (isSigningUp) dataPayload.username = username;
        // שליחה לשרת
        fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dataPayload),
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);

                    // --- שינוי לפי החומר: העברת השם ב-URL ---
                    let loggedInUser = '';

                    if (isSigningUp) {
                        loggedInUser = username;
                    } else {
                        // חילוץ השם מתוך הודעת השרת ("Welcome back, Adam!")
                        const msg = data.message;
                        if (msg.includes('Welcome back, ')) {
                            loggedInUser = msg.replace('Welcome back, ', '').replace('!', '');
                        } else {
                            loggedInUser = 'Guest';
                        }
                    }

                    // מעבר לדף הפרופיל עם פרמטר בכתובת
                    // דוגמה: profile.html?username=Adam
                    window.location.href = `profile.html?username=${encodeURIComponent(loggedInUser)}`;

                } else {
                    showError(data.message);
                }
            })
            .catch((error) => {
                console.error('Error:', error);
                showError('Server connection failed.');
            });
    });
    // פונקציה להצגת הודעות שגיאה עם אנימציה
    function showError(message) {
        errorMessage.textContent = message;
        void errorMessage.offsetWidth;
        errorMessage.classList.add('error-shake');
    }
});