document.addEventListener('DOMContentLoaded', () => {
    const recipeGrid = document.getElementById('recipe-grid');
    const welcomeMsg = document.getElementById('welcome-message');
    const groupsContainer = document.getElementById('groups-row');

    const params = new URLSearchParams(window.location.search);
    const usernameFromUrl = params.get('username');

    let allUserRecipes = [];

    if (usernameFromUrl) {
        welcomeMsg.textContent = `Hello, ${usernameFromUrl}`;
        loadUserRecipes(usernameFromUrl);
    } else {
        welcomeMsg.textContent = `Hello, Guest`;
        recipeGrid.innerHTML = '<p style="text-align:center;">Please log in to see your recipes.</p>';
    }

    const addRecipeBtn = document.getElementById('add-recipe-btn');  // כפתור הוספת מתכון חדש
    if (addRecipeBtn) {
        addRecipeBtn.addEventListener('click', () => {
            const userParam = usernameFromUrl ? `?username=${encodeURIComponent(usernameFromUrl)}` : '';
            window.location.href = `new_recipe.html${userParam}`;
        });
    }

    function loadUserRecipes(username) // טוען את כל המתכונים של המשתמש
    {
        fetch(`/recipes?username=${encodeURIComponent(username)}`)
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(recipes => {
                allUserRecipes = recipes;
                // נטען את רשימת הלייבלים מהשרת כדי להציג גם לייבלים ריקים (שאין בהם מתכונים עדיין)
                loadLabelsAndInitTabs(username, recipes);
            })
            .catch(error => {
                console.error('Error fetching recipes:', error);
                recipeGrid.innerHTML = '<p class="error-text">Failed to load recipes.</p>';
            });
    }

    function loadLabelsAndInitTabs(username, recipes) // טוען את הלייבלים של המשתמש ומאתחל את הטאבים
    {
        fetch(`/api/labels/${encodeURIComponent(username)}`)
            .then(res => res.json())
            .then(labelsData => {
                initTabs(recipes, labelsData);
                renderRecipes(recipes); // הצגת הכל כברירת מחדל
            })
            .catch(err => console.error("Error loading labels", err));
    }

    function initTabs(recipes, userLabels) // אתחול הטאבים לפי הלייבלים
    {
        groupsContainer.innerHTML = '';

        // 1. All
        groupsContainer.appendChild(createTabElement('All', 'all', true));

        // 2. New (מתכונים ללא תווית)
        const hasNewRecipes = recipes.some(r => !r.label_name);
        if (hasNewRecipes) {
            groupsContainer.appendChild(createTabElement('New', 'new', false));
        }

        // 3. לייבלים מהדאטהבייס
        userLabels.forEach(label => {
            groupsContainer.appendChild(createTabElement(label.label_name, label.label_name, false));
        });

        // 4. כפתור הפלוס (+)
        const addBtn = document.createElement('button');
        addBtn.className = 'group-tab add-group-btn';
        addBtn.textContent = '+';
        addBtn.title = "Create new label";
        addBtn.addEventListener('click', () => handleAddLabel());
        groupsContainer.appendChild(addBtn);
    }

    function handleAddLabel()  // טיפול ביצירת לייבל חדש
    {
        const newLabelName = prompt("Enter new label name:");
        if (newLabelName && newLabelName.trim() !== "") {
            fetch('/api/labels', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: usernameFromUrl,
                    label_name: newLabelName.trim()
                })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // טוען מחדש את הדף או את הטאבים כדי לראות את השינוי
                        loadUserRecipes(usernameFromUrl);
                    } else {
                        alert("Error creating label");
                    }
                });
        }
    }

    function createTabElement(text, filterValue, isActive) // יצירת אלמנט טאבים
    {
        const btn = document.createElement('button');
        btn.className = `group-tab ${isActive ? 'active' : ''}`;
        btn.textContent = text;

        btn.addEventListener('click', () => {
            document.querySelectorAll('.group-tab').forEach(b => {
                if (!b.classList.contains('add-group-btn')) b.classList.remove('active');
            });
            btn.classList.add('active');
            filterRecipes(filterValue);
        });

        return btn;
    }

    function filterRecipes(filter)// סינון מתכונים לפי הטאב שנבחר
    {
        let filtered = [];
        if (filter === 'all') {
            filtered = allUserRecipes;
        } else if (filter === 'new') {
            filtered = allUserRecipes.filter(r => !r.label_name);
        } else {
            filtered = allUserRecipes.filter(r => r.label_name === filter);
        }
        renderRecipes(filtered);
    }

    function renderRecipes(recipes)// הצגת המתכונים ברשת
    {
        recipeGrid.innerHTML = '';
        if (recipes.length === 0) {
            recipeGrid.innerHTML = '<p style="text-align:center;">No recipes in this category.</p>';
            return;
        }
        recipes.forEach(recipe => /* יצירת כרטיס מתכון */ {
            recipeGrid.appendChild(createRecipeCard(recipe, usernameFromUrl));
        });
    }

    function createRecipeCard(recipe, username) // יצירת כרטיס מתכון בודד
    {
        const article = document.createElement('article');
        article.className = 'recipe-card';
        article.setAttribute('data-id', recipe.id);

        const imageUrl = recipe.image_path && recipe.image_path !== 'null'
            ? recipe.image_path
            : 'images/default-recipe.jpg';

        const labelDisplay = recipe.label_name // אם יש לייבל מציג אותו
            ? `<span style="font-size:0.8rem; background:#fff3c4; padding:2px 6px; border-radius:4px; margin-bottom:5px; display:inline-block;">${recipe.label_name}</span>`
            : '';

        // תוכן הכרטיס
        article.innerHTML = ` 
            <button class="delete-recipe-btn" title="Remove recipe">✕</button>

            <div class="recipe-image-wrapper">
                <img src="${imageUrl}" alt="${recipe.title}" class="recipe-image">
            </div>
            <div class="recipe-card-body">
                ${labelDisplay}
                <h3 class="recipe-name">${recipe.title}</h3>
                <p class="recipe-meta">Serves: ${recipe.servings}</p>
                <button class="secondary-button view-button">View recipe</button>
            </div>
        `;

        // לוגיקה למעבר לעמוד המתכון
        const viewBtn = article.querySelector('.view-button');
        viewBtn.addEventListener('click', () => {
            window.location.href = `recipe.html?id=${recipe.id}&username=${encodeURIComponent(username)}`;
        });

        // לוגיקה למחיקת המתכון (ניתוק הקשר)
        const deleteBtn = article.querySelector('.delete-recipe-btn');
        deleteBtn.addEventListener('click', (e) => {
            // מונע לחיצה בטעות על דברים אחרים בכרטיס אם היו
            e.stopPropagation();

            // הודעת האזהרה שביקשת
            const confirmed = confirm("Are you sure? A deleted recipe cannot be restored without rewriting it from scratch.");

            if (confirmed) {
                fetch('/api/user_recipes', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: username, recipeId: recipe.id })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            // אם הצליח - טוען מחדש את המתכונים כדי שהכרטיס ייעלם
                            loadUserRecipes(username);
                        } else {
                            alert("Error removing recipe.");
                        }
                    })
                    .catch(err => console.error(err));
            }
        });

        return article;// מחזיר את אלמנט הכרטיס
    }
});