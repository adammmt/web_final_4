document.addEventListener('DOMContentLoaded', () => {
    const titleEl = document.getElementById('recipe-title');//  כותרת המתכון
    const imageEl = document.getElementById('recipe-main-image');// תמונת המתכון
    const servingsInput = document.getElementById('current-servings');// שדה מספר מנות נוכחי
    const ingredientsList = document.getElementById('ingredients-list');// רשימת מרכיבים
    const instructionsEl = document.getElementById('recipe-instructions');// אלמנטים בדף המתכון
    const welcomeMsg = document.getElementById('welcome-message');// הודעת ברוך הבא
    const labelSelect = document.getElementById('recipe-label-select');// לייבל של המתכון

    // כפתורי ניווט ושיתוף
    const backBtn = document.getElementById('back-profile-btn');// כפתור חזרה לפרופיל
    const addRecipeBtn = document.getElementById('add-recipe-btn');// כפתור הוספת מתכון חדש
    const shareBtn = document.getElementById('share-btn');// כפתור שיתוף מתכון
    const shareControls = document.getElementById('share-controls');//  שליטה בשיתוף מתכון
    const sendShareBtn = document.getElementById('send-share-btn');// כפתור לשליחת השיתוף
    const shareUsernameInput = document.getElementById('share-username');// שדה להזנת שם משתמש
    const shareMessage = document.getElementById('share-message');// הודעות שיתוף

    const params = new URLSearchParams(window.location.search);// שליפת פרמטרים מה-URL
    const recipeId = params.get('id');
    const username = params.get('username') || 'Guest';

    if (welcomeMsg) welcomeMsg.textContent = `Hello, ${username}`;

    if (backBtn) // האזנה לכפתור חזרה לפרופיל
    {
        backBtn.addEventListener('click', () => {
            window.location.href = `profile.html?username=${encodeURIComponent(username)}`;
        });
    }

    if (addRecipeBtn) // האזנה לכפתור הוספת מתכון חדש
    {
        addRecipeBtn.addEventListener('click', () => {
            window.location.href = `new_recipe.html?username=${encodeURIComponent(username)}`;
        });
    }

    let currentRecipeData = null;
    let currentServings = 4;

    if (recipeId) {
        fetch(`/api/recipe/${recipeId}?username=${encodeURIComponent(username)}`)
            .then(response => {
                if (!response.ok) throw new Error('Recipe not found');
                return response.json();
            })
            .then(recipe => {
                currentRecipeData = recipe;
                currentRecipeData.baseServings = recipe.servings;
                initRecipeView();
                loadLabelsForDropdown(username, recipe.label_id);
            })
            .catch(err => {
                console.error(err);
                titleEl.textContent = "Recipe not found";
                instructionsEl.textContent = "Could not load recipe data.";
            });
    } else {
        titleEl.textContent = "No Recipe ID provided";
    }

    function initRecipeView() // אתחול תצוגת המתכון
    {
        titleEl.textContent = currentRecipeData.title;

        const imgSrc = (currentRecipeData.image && currentRecipeData.image !== 'null')
            ? currentRecipeData.image
            : (currentRecipeData.image_path || 'images/default-recipe.jpg');

        imageEl.src = imgSrc;
        imageEl.alt = currentRecipeData.title;
        imageEl.style.display = 'block';

        currentServings = currentRecipeData.baseServings;
        servingsInput.value = currentServings;
        instructionsEl.textContent = currentRecipeData.instructions;
        renderIngredients();
    }

    function loadLabelsForDropdown(username, currentLabelId) {
        fetch(`/api/labels/${encodeURIComponent(username)}`)
            .then(res => res.json())
            .then(labels => {
                labelSelect.innerHTML = '<option value="">No Label (New)</option>';

                labels.forEach(label => {
                    const option = document.createElement('option');
                    option.value = label.id;
                    option.textContent = label.label_name;
                    if (currentLabelId && label.id === currentLabelId) {
                        option.selected = true;
                    }
                    labelSelect.appendChild(option);
                });

                labelSelect.addEventListener('change', (e) => {
                    const newLabelId = e.target.value === "" ? null : e.target.value;
                    updateRecipeLabel(username, currentRecipeData.id, newLabelId);
                });
            })
            .catch(err => console.error("Error loading labels", err));
    }

    function updateRecipeLabel(username, recipeId, labelId) {
        fetch('/api/recipe/update-label', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, recipe_id: recipeId, label_id: labelId })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    labelSelect.style.borderColor = "green";
                    setTimeout(() => labelSelect.style.borderColor = "", 1000);
                } else {
                    alert("Failed to update label");
                }
            });
    }

    function renderIngredients() // הצגת רשימת המרכיבים עם התאמת כמויות
    {
        ingredientsList.innerHTML = '';
        const ratio = currentServings / currentRecipeData.baseServings;
        let warningFound = false;

        if (currentRecipeData.ingredients) {
            currentRecipeData.ingredients.forEach(item => {
                let newQty = item.quantity * ratio;
                let displayQty = Number.isInteger(newQty) ? newQty : parseFloat(newQty.toFixed(2));

                const li = document.createElement('li');
                li.innerHTML = `<strong>${item.name}</strong>: `;

                const qtySpan = document.createElement('span');
                qtySpan.className = 'ingredient-quantity-display';
                qtySpan.textContent = `${displayQty} ${item.unit}`;

                const isWholeUnit = (item.unit === 'units' || item.unit === 'unit');
                if (isWholeUnit && !Number.isInteger(newQty)) {
                    qtySpan.classList.add('warning');
                    warningFound = true;
                }

                li.appendChild(qtySpan);
                ingredientsList.appendChild(li);
            });
        }

        const warningEl = document.getElementById('ingredients-warning');
        if (warningEl) {
            warningEl.style.display = warningFound ? 'block' : 'none';
        }
    }

    servingsInput.addEventListener('input', (e) => {
        const val = parseInt(e.target.value, 10);
        if (!isNaN(val) && val >= 1) {
            currentServings = val;
            renderIngredients();
        }
    });

    // --- לוגיקת שיתוף מתוקנת ---

    // 1. פתיחה/סגירה של תפריט השיתוף (היה חסר בקובץ שלך)
    shareBtn.addEventListener('click', () => {
        const isVisible = shareControls.style.display === 'flex';
        shareControls.style.display = isVisible ? 'none' : 'flex';
        shareBtn.textContent = isVisible ? 'Share' : 'Cancel';
        shareMessage.textContent = '';
        shareUsernameInput.value = '';
        sendShareBtn.disabled = true;
    });

    // 2. ולידציה לשם משתמש (מינימום 3 תווים)
    shareUsernameInput.addEventListener('input', () => {
        const val = shareUsernameInput.value.trim();
        sendShareBtn.disabled = val.length < 3;
    });

    // 3. שליחה לשרת (הוסרה הכפילות)
    sendShareBtn.addEventListener('click', () => {
        const targetUser = shareUsernameInput.value.trim();

        if (targetUser) {
            // חיווי שהשליחה מתבצעת
            sendShareBtn.textContent = 'Sending...';
            sendShareBtn.disabled = true;

            fetch('/api/share', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    recipeId: currentRecipeData.id,
                    targetUsername: targetUser
                })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        shareMessage.style.color = 'green';
                        shareMessage.textContent = `Recipe sent to ${targetUser}!`;
                        setTimeout(() => {
                            shareControls.style.display = 'none';
                            shareBtn.textContent = 'Share';
                            // איפוס הכפתור
                            sendShareBtn.textContent = 'Send';
                            sendShareBtn.disabled = false;
                        }, 2000);
                    } else {
                        shareMessage.style.color = 'red';
                        shareMessage.textContent = data.message || "Failed to share.";
                        sendShareBtn.textContent = 'Send';
                        sendShareBtn.disabled = false;
                    }
                })
                .catch(err => {
                    console.error(err);
                    shareMessage.style.color = 'red';
                    shareMessage.textContent = "Network error.";
                    sendShareBtn.textContent = 'Send';
                    sendShareBtn.disabled = false;
                });
        }
    });
});