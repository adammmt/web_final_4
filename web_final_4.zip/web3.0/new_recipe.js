document.addEventListener('DOMContentLoaded', () => {
    // 1. חילוץ שם המשתמש מהכתובת
    const params = new URLSearchParams(window.location.search);
    const username = params.get('username') || 'Guest';

    // 2. עדכון כפתור ה-Home
    const homeBtn = document.querySelector('.home-button');
    if (homeBtn) {
        homeBtn.href = `profile.html?username=${encodeURIComponent(username)}`;
    }

    const form = document.getElementById('new-recipe-form'); // טופס יצירת מתכון חדש
    const ingredientsTableBody = document.querySelector('#ingredients-table tbody');// גוף הטבלה למרכיבים
    const addIngredientBtn = document.getElementById('add-ingredient-btn');// כפתור להוספת מרכיב
    const generalError = document.getElementById('general-error');// הודעת שגיאה כללית

    // --- אתחול: הוספת שורה ראשונה באופן אוטומטי ---
    addIngredientRow();

    // --- האזנה לכפתור "הוסף מרכיב" ---
    if (addIngredientBtn) {
        addIngredientBtn.addEventListener('click', addIngredientRow);
    }

    // --- פונקציה להוספת שורת מרכיב ---
    function addIngredientRow() {
        const newRow = ingredientsTableBody.insertRow();

        const unitOptions = `
            <option value="" disabled selected>Select Unit</option>
            <option value="units">Units </option>
            <option value="cups">Cups</option>
            <option value="tsp">Teaspoons</option>
            <option value="tbsp">Tablespoons</option>
            <option value="g">Grams</option>
        `;

        newRow.innerHTML = `
            <td><input type="text" placeholder="e.g., Flour" class="ingredient-name" required></td>
            <td>
                <select class="unit-measure" required style="width: 100%; padding: 8px;">
                    ${unitOptions}
                </select>
            </td>
            <td><input type="number" min="0" step="0.01" placeholder="1.5" class="quantity" required></td>
            <td><button type="button" class="remove-ingredient-btn">X</button></td>
        `;

        // הוספת האזנה לכפתור המחיקה של השורה הספציפית הזו
        newRow.querySelector('.remove-ingredient-btn').addEventListener('click', (e) => {
            if (ingredientsTableBody.rows.length > 1) {
                e.target.closest('tr').remove();
            } else {
                alert("You must have at least one ingredient!");
            }
        });
    }

    // --- שליחת הטופס (כולל תמונה) ---
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        generalError.textContent = '';
        document.querySelectorAll('.error-text').forEach(el => el.textContent = '');

        if (!validateForm()) {
            generalError.textContent = 'Please fix the errors above.';
            return;
        }

        // שימוש ב-FormData לשליחת קובץ ונתונים
        const formData = new FormData();

        formData.append('username', username);
        formData.append('title', document.getElementById('recipe-name').value.trim());
        formData.append('servings', document.getElementById('servings').value);
        formData.append('instructions', document.getElementById('instructions').value);

        // הוספת הקובץ (אם קיים)
        const imageInput = document.getElementById('recipe-image');
        if (imageInput.files[0]) {
            formData.append('image', imageInput.files[0]);
        }

        // איסוף המרכיבים למערך
        const ingredients = [];
        const rows = ingredientsTableBody.querySelectorAll('tr');
        rows.forEach(row => {
            const nameInput = row.querySelector('.ingredient-name');
            const unitSelect = row.querySelector('.unit-measure');
            const qtyInput = row.querySelector('.quantity');

            ingredients.push({
                name: nameInput.value.trim(),
                unit: unitSelect.value,
                quantity: parseFloat(qtyInput.value)
            });
        });

        // הוספת המרכיבים ל-FormData כ-JSON
        formData.append('ingredients', JSON.stringify(ingredients));

        // שליחה לשרת
        fetch('/new-recipe', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Recipe saved successfully!');
                    window.location.href = `profile.html?username=${encodeURIComponent(username)}`;// חזרה לפרופיל
                } else {
                    generalError.textContent = 'Server Error: ' + data.message;
                }
            })
            .catch(err => {
                console.error(err);
                generalError.textContent = 'Network error occurred.';
            });
    });

    // --- ולידציה של הטופס ---
    function validateForm() {
        let isValid = true;
        const recipeName = document.getElementById('recipe-name').value.trim();
        const servings = document.getElementById('servings').value;
        const instructions = document.getElementById('instructions').value.trim();

        if (recipeName === '') {
            document.getElementById('error-name').textContent = 'Recipe Name is required.';
            isValid = false;
        }
        if (servings === '' || parseInt(servings) < 1) {
            document.getElementById('error-servings').textContent = 'Servings must be a positive number.';
            isValid = false;
        }
        if (instructions === '') {
            document.getElementById('error-instructions').textContent = 'Preparation instructions are required.';
            isValid = false;
        }

        const rows = ingredientsTableBody.querySelectorAll('tr');
        let ingredientsCount = 0;

        rows.forEach(row => // בדיקת כל שורת מרכיב
        {
            const name = row.querySelector('.ingredient-name').value.trim();
            const unit = row.querySelector('.unit-measure').value;
            const quantity = row.querySelector('.quantity').value;

            if (name === '' || unit === '' || quantity === '') // כל השדות חייבים להיות מלאים
            {
                document.getElementById('error-ingredients').textContent = 'All ingredient fields must be filled.';
                isValid = false;
            }
            ingredientsCount++;
        });

        if (ingredientsCount === 0) // לפחות מרכיב אחד נדרש
        {
            document.getElementById('error-ingredients').textContent = 'At least one ingredient is required.';
            isValid = false;
        }

        return isValid;
    }
});